
document.getElementById("pay-button")?.addEventListener("click", function(e){
    var name = document.getElementById("name")?.value;
    var email = document.getElementById("email")?.value;
    var address = document.getElementById("address")?.value;
    var amount = document.getElementById("amount")?.value * 100;

    if(!name || !email || !address || !amount){
        alert("Please fill all fields");
        return;
    }

    var options = {
        "key": "YOUR_RAZORPAY_KEY",
        "amount": amount,
        "currency": "INR",
        "name": "Kavyashree One Gram Gold",
        "description": "Purchase Gold Jewelry",
        "handler": function (response){
            alert("Payment successful! Payment ID: " + response.razorpay_payment_id);
        },
        "prefill": {"name": name, "email": email},
        "theme": {"color": "#d4af37"},
        "method": {"upi": true,"card": true,"wallet": true,"netbanking": false}
    };

    var rzp1 = new Razorpay(options);
    rzp1.open();
    e.preventDefault();
});
